﻿$o = new-object -com shell.application

($o.Namespace("shell:::{679F85CB-0220-4080-B29B-5540CC05AAB6}").Items() | Where-Object { $_.Path -EQ '\\wsl$\docker-desktop-data\data\docker\volumes\docker-dev\_data' }).InvokeVerb("unpinfromhome")