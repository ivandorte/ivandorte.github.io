﻿$o = new-object -com shell.application
$o.Namespace('\\wsl$\docker-desktop-data\data\docker\volumes\docker-dev\_data').Self.InvokeVerb("pintohome")