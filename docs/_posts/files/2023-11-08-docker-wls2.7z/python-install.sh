#! /bin/bash

#~ Update and upgrade the system
apt-get update
apt-get upgrade
apt-get dist-upgrade

#~ Install aptitude, dpkg, git
apt-get install aptitude dpkg git -y

#~ Install Python 3.9 (Latest)
apt-get install build-essential zlib1g-dev libncurses5-dev libgdbm-dev libnss3-dev libssl-dev libreadline-dev libffi-dev libsqlite3-dev wget libbz2-dev -y
wget https://www.python.org/ftp/python/3.9.18/Python-3.9.18.tgz
tar xzf Python-3.9.18.tgz
rm Python-3.9.18.tgz
cd Python-3.9.18
./configure --enable-optimizations
make altinstall

cd ..

update-alternatives --install /usr/bin/python python /usr/local/bin/python3.9 1
update-alternatives --set python /usr/local/bin/python3.9
apt-get install python3-distutils python3-lib2to3 python3-venv python3-dev python3-gdbm python3-setuptools -y

#~ Install PIP
curl -s https://bootstrap.pypa.io/get-pip.py -o get-pip.py
python get-pip.py --force-reinstall
rm get-pip.py

#~ Upgrade PIP
python -m pip install --upgrade pip

#~ Cleaning...
apt-get update
apt-get autoremove
apt-get clean
apt-get autoclean
aptitude purge ~c
