$OutPath = "C:\Users\$Env:UserName\Desktop\VM_Vagrant"

New-Item -Path $OutPath -Type Directory

$SourceFilePath = "C:\Users\$Env:UserName\ubuntu-vagrant\vagrant-start.bat"
$ShortcutPath = "$OutPath\Start VM.lnk"
$WScriptObj = New-Object -ComObject ("WScript.Shell")
$shortcut = $WscriptObj.CreateShortcut($ShortcutPath)
$shortcut.TargetPath = $SourceFilePath
$Shortcut.WorkingDirectory = "C:\Users\$Env:UserName\ubuntu-vagrant"
$shortcut.Save()

$SourceFilePath = "C:\Users\$Env:UserName\ubuntu-vagrant\vagrant-stop.bat"
$ShortcutPath = "$OutPath\Stop VM.lnk"
$WScriptObj = New-Object -ComObject ("WScript.Shell")
$shortcut = $WscriptObj.CreateShortcut($ShortcutPath)
$shortcut.TargetPath = $SourceFilePath
$Shortcut.WorkingDirectory = "C:\Users\$Env:UserName\ubuntu-vagrant"
$shortcut.Save()

pause

